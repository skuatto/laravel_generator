<?php
 
class PublicController extends BaseController {
    public function principal(){

    	return View::make('layouts.principal',array('menu_activo' => 0))
			   		->with('idiomas', Idioma::All())
			   		->with('idioma_activo', Idioma::lenguaje()->get())
			   		->with('quienes_somos', QuienesSomos::first()->idioma()->get() )
			   		->with('personales', Personal::activo()->ordenar()->get() )
					->with('que_hacemos', QueHacemos::first()->idioma()->get() )
					->with('que_hacemos_imagen', QueHacemos::first()->imagen()->get() );
			   		//->with('portfolio', Portfolio::first()->idioma()->get()  )
	}
}

?>