<?php namespace App\Controllers\Admin;

use App\Services\Validators\ContrasenyaValidator;
use Auth, BaseController, Form, Input, Redirect, Sentry, View, Notification;

class AuthController extends BaseController {

        /**
         * Display the login page
         * @return View
         */
        public function getLogin()
        {
                return View::make('admin.auth.login');
        }

        /**
         * Login action
         * @return Redirect
         */
        public function postLogin()
        {
                $credentials = array(
                        'email'    => Input::get('email'),
                        'password' => Input::get('password')
                );
                try
                {
                        $user = Sentry::authenticate($credentials, false);

                        if ($user)
                        {
                                return Redirect::route('admin.principal.edit');
                        }
                }
             
                
                catch (\Cartalyst\Sentry\Users\LoginRequiredException $e)
                {
                   return Redirect::route('admin.login')->withErrors(array('login' => 'Es obligatorio introducir usuario.' ));
                }
                catch (\Cartalyst\Sentry\Users\PasswordRequiredException $e)
                {
                   return Redirect::route('admin.login')->withErrors(array('login' => 'Es obligatorio introducir contraseña' ));
                }
                catch (\Cartalyst\Sentry\Users\WrongPasswordException $e)
                {
                   return Redirect::route('admin.login')->withErrors(array('login' => 'La contraseña es incorrecta' ));
                }
                catch (\Cartalyst\Sentry\Users\UserNotFoundException $e)
                {
                   return Redirect::route('admin.login')->withErrors(array('login' => 'El usuario no existe.' ));
                }
                  /* catch(\Exception $e)
                {
                        return Redirect::route('admin.login')->withErrors(array('login' => $e->getMessage()));
                }*/

                      
       
        }

        /**
         * Logout action
         * @return Redirect
         */
        public function getLogout()
        {
                Sentry::logout();

                return Redirect::route('admin.login');
        }

        public function postCambiarContrasenya(){
                $validation = new contrasenyaValidator;
                $usuario  =  Sentry::getUser();
                if ($validation->passes())
                { 
                    if($usuario->checkPassword(Input::get('old_password'))){
                          
                            $usuario->password = Input::get('password'); 
                            $usuario->save();
                            \Notification::success('La contraseña fue guardada correctamente.');
                    
                    }else{
                        \Notification::error('La contraseña introducida no coincide.');

                    }
                }
                return Redirect::route('admin.cambiarcontrasenya')->withErrors($validation->errors);
        }

        public function getCambiarContrasenya()
        {
                return View::make('admin.auth.contrasenya')->with('navegador_active', 7);
        }

}