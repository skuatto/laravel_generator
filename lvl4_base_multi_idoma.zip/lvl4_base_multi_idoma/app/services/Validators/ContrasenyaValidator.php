<?php namespace App\Services\Validators;
 
class ContrasenyaValidator extends Validator {
 
    public static $rules = array(
    	'old_password' => 'required',
        'password' => 'required|confirmed|min:4'
    );
 
}
