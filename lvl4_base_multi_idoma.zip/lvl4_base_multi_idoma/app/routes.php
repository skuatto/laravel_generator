<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

$locale = Request::segment(1);
if (!in_array($locale, Config::get('app.languages'))) {
    $locale = 'es';
}

Route::group(array('prefix' => $locale), function()
{ 
	Route::get('/', array('as' => 'principal', 'uses' => 'PublicController@principal'));
	 
});

Route::get('admin/logout',  array('as' => 'admin.logout',      'uses' => 'App\Controllers\Admin\AuthController@getLogout'));
Route::get('admin/login',   array('as' => 'admin.login',       'uses' => 'App\Controllers\Admin\AuthController@getLogin'));
Route::post('admin/login',  array('as' => 'admin.login.post',  'uses' => 'App\Controllers\Admin\AuthController@postLogin'));

Route::group(array('prefix' => 'admin', 'before' => 'auth.admin'), function()
{
	Route::get('/',                'App\Controllers\Admin\PrincipalController@edit');
	Route::post('/',                'App\Controllers\Admin\PrincipalController@update');

	Route::get('principal', array('as' => 'admin.principal.edit', 'uses' => 'App\Controllers\Admin\PrincipalController@edit'));
	Route::post('principal', array('as' => 'admin.principal.update', 'uses' => 'App\Controllers\Admin\PrincipalController@update'));

	Route::get('logout' ,array('as' => 'admin.logout', 'uses' => 'App\Controllers\Admin\AuthController@getLogout'));
	Route::get('cambiarcontrasenya', array( 'as' => 'admin.cambiarcontrasenya','uses' => 'App\Controllers\Admin\AuthController@getCambiarContrasenya'));
	Route::post('cambiarcontrasenya', array( 'uses' => 'App\Controllers\Admin\AuthController@postCambiarContrasenya'));
});


