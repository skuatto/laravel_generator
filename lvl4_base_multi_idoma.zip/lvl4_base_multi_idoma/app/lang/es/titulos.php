<?php 

return array(

	/*
		
	*/

	'quienes_somos' => 'Quienes somos',

	'productos'     => 'Modelos SPS',

	'productos_derecha'     => 'Tablas SPS',

	'accesorios'     => 'Accesorios SPS',

	'accesorio_derecha'     => 'Accesorios SPS',

	'galeria'     => 'Galería',

	'contacto_venta'     => 'Contacto-venta',

);