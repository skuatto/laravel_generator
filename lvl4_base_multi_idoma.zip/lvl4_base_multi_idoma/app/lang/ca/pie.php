<?php 

return array(

	/*
		
	*/

	'aviso_legal' => 'Avis Legal',

	'y' => 'i',

	'politica' => 'Política de privacitat',	

	'email' => 'E-mail',

	'comenta' => 'Comenta',

	'acepta_politica' => 'Accepta la política de privacitat',

	'enviar' => 'Envia',

	'siguenos' => 'segueix-nos',

	'informacion' => '	T.  +34 930 133 319<br>
						M. +34 696 566 441<br>
						<br>
						La Marinada - Local C<br>
						08392 Llavaneres - Barcelona, Catalonia - Spain',

	'contacto'     => 'CONTACTE',

);