<?php 

return array(

	/*
		
	*/

	'quienes_somos' => 'About us',

	'productos'     => 'Models SPS',

	'productos_derecha'     => 'Tables SPS',

	'accesorios'     => 'Accessories SPS',

	'accesorio_derecha'     => 'Accessories SPS',

	'galeria'     => 'Pictures',

	'contacto_venta'     => 'Contact',

);