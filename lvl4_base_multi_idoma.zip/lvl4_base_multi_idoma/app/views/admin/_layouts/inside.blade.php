@extends('admin._layouts.default')
@section('js_ready')

@stop
@section('main')

<div id="navigation">
	<div class="container-fluid">
		<a href="#" id="brand">L'ESTUDI</a>
		<a href="#" class="toggle-nav" rel="tooltip" data-placement="bottom" title="Toggle navigation"><i class="icon-reorder"></i></a>
		<!-- Navegador -->
		<ul class='main-nav'>

		</ul>
		<div class="user">
			<ul class='main-nav'>
				<li @if($navegador_active == 7) class='active' @endif><a href="{{ URL::route('admin.cambiarcontrasenya') }}">Cambiar contraseña</a></li>
				<li><a href="{{ URL::route('admin.logout') }}">Salir</a></li>
			</ul>
		</div>
	</div>
</div>
<div class="container-fluid" id="content">
	<div id="left">

	</div>

	<div id="main" style="margin-left: 200px;">
		<div class="container-fluid">
			<div class="page-header">
				
					<h1>@yield('titulo')</h1>
			
				
			</div>
			@yield('breadcumb')
			<div class="row-fluid">
				<div class="span12">
					@yield('submain')
				</div>	
			</div>
		</div>
	</div>
</div>

@stop

