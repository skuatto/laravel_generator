<!doctype html>
<html>

<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <!-- Apple devices fullscreen -->
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <!-- Apple devices fullscreen -->
        <meta names="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        
        <title>Admin - Inicio</title>

        <!-- Bootstrap -->
        <link rel="stylesheet" href="{{URL::asset('css/admin/bootstrap.min.css')}}">
        <!-- Bootstrap responsive -->
        <!-- <link rel="stylesheet" href="{{URL::asset('css/admin/bootstrap-responsive.min.css')}}"> -->
        <!-- Theme CSS -->
        <link rel="stylesheet" href="{{URL::asset('css/admin/style.css')}}">
        <link rel="stylesheet" href="{{URL::asset('css/admin/plugins/chosen/chosen.css')}}">
        <link rel="stylesheet" href="{{URL::asset('css/admin/jquery.fileupload.css')}}">
        <link rel="stylesheet" href="{{URL::asset('css/admin/jquery.fileupload-ui.css')}}">

        <!-- jQuery -->
        <script src="{{URL::asset('js/admin/jquery.min.js')}}"></script>
        <script src="{{URL::asset('js/admin/plugins/chosen/chosen.jquery.min.js')}}"></script>
        <!-- Validation -->
        <script src="{{URL::asset('js/admin/plugins/validation/jquery.validate.min.js')}}"></script>
        <script src="{{URL::asset('js/admin/plugins/validation/additional-methods.min.js')}}"></script>
        <script src="{{URL::asset('js/admin/plugins/ckeditor/ckeditor.js')}}"></script>      
        <!-- CKEDITOR -->
        <script src="{{URL::asset('js/admin/bootstrap.min.js')}}"></script> 
        <script src="{{URL::asset('js/admin/plugins/fileupload/bootstrap-fileupload.min.js')}}"></script> 
        

    

        <!--[if lte IE 9]>
                <script src="js/plugins/placeholder/jquery.placeholder.min.js"></script>
                <script>
                        $(document).ready(function() {
                                $('input, textarea').placeholder();
                        });
                </script>
        <![endif]-->
        

        <!-- Favicon -->
        <link rel="shortcut icon" href="{{URL::asset('images/admin/favicon.ico')}}" />
        <!-- Apple devices Homescreen icon -->
        <link rel="apple-touch-icon-precomposed" href="{{URL::asset('images/admin/apple-touch-icon-precomposed.png')}}" />
        <script>
                function cambiarPestanya(id_pestanya){
                    //Desactivamos la pestaña
                    $(".nav-tabs .active").removeClass('active'); 

                    //Activamos la nueva pestaña
                    $("#nav_tab_"+id_pestanya).addClass('active');

                    //Escondemos el contenedor
                     $(".tab").each(function(i) {
                       $(this).hide();
                    });

                    //Mostramos el contenedor
                    $("#tab_"+id_pestanya).show();
                }
                $( document ).ready(function() {
                    @yield('js_ready')

                    

                });
                
        </script>
</head>

 @yield('main')


</html>
