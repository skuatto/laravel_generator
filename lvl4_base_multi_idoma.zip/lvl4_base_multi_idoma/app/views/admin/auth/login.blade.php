@extends('admin._layouts.default')
 
@section('main')
 
<body class='login'>
        <div class="wrapper">
        <!-- <a href=""><img src="{{URL::asset('images/admin/logo-home.png')}}" alt="" class='retina-ready' width="59" height="49"> -->
                <h1><a href="">GESTOR</a></h1>
                <div class="login-body">
                        <h2>INICIAR SESIÓN</h2>
                        {{ Form::open(array('class'=>'form-validate')) }}
                                <div class="control-group">
                                        <div class="email controls">
                                                {{ Form::text('email', null, array('class'=>'input-block-level', 'placeholder'=>'Usuario')) }}
                                        </div>
                                </div>
                                <div class="control-group">
                                        <div class="pw controls">
                                                {{ Form::password('password', array('class'=>'input-block-level', 'placeholder'=>'Contraseña')) }}
                                        </div>
                                </div>
                                <div class="submit">
                                        <div class="remember">
                                             @if ($errors->has('login'))
                                                <div class="alert alert-error">{{ $errors->first('login', ':message') }}</div>
                                                @endif    
                                        </div>
                                        {{ Form::submit('Entrar', array('class'=>'btn btn-primary'))}}       
                                                        <!-- value="Iniciar sesión" -->
                                </div>
                               
                        {{ Form::close() }}
                </div>
        </div>

</body>
@stop

