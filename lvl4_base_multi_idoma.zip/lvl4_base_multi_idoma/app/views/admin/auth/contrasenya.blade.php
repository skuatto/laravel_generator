@extends('admin._layouts.inside')
@section('js_ready')

@stop
@section('titulo')
    Cambiar contraseña
@stop

@section('submain')


    {{ Form::open(array('method' => 'post')) }}
        <div class="row-fluid">
            <div class="span5">
                {{ Notification::showAll() }}
               
                @if ($errors->any())
                <div class="alert alert-error">
                    {{ implode('<br>', $errors->all()) }}
                </div>
                @endif
            </div>
        </div>
        <div class="row-fluid">
            <div class="span3">

              
               {{ Form::label('old_password', 'Contraseña actual: ') }}
               <div class="controls">
               {{ Form::password('old_password', array('class'=>'input-block-level')) }}
               </div>

               {{ Form::label('password', 'Nueva contraseña: ') }}
               <div class="controls">
               {{ Form::password('password', array('class'=>'input-block-level')) }}
               </div>

               {{ Form::label('password_confirmation', 'Repite la contraseña: ') }}
               <div class="controls">
               {{ Form::password('password_confirmation', array('class'=>'input-block-level')) }}
               </div>
               
               <div class="controls">
                    {{ Form::submit('Guardar', array('class' => 'btn btn-primary')) }}
                </div>
            </div>
        </div>

    {{ Form::close() }}

@stop