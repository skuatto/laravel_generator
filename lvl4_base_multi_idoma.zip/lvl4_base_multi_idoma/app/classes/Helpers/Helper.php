<?php namespace Helpers;
Use Str;
class Helper {

	public static function tokenTruncate($string, $your_desired_width, $addString = '')
	{
	  if (strlen($string) >= $your_desired_width ){
		  $parts = preg_split('/([\s\n\r]+)/', $string, null, PREG_SPLIT_DELIM_CAPTURE);
		  $parts_count = count($parts);

		  $length = 0;
		  $last_part = 0;
		  for (; $last_part < $parts_count; ++$last_part) {
		    $length += strlen($parts[$last_part]);
		    if ($length > $your_desired_width) { break; }
		  }
		  
		  return implode(array_slice($parts, 0, $last_part)) . $addString;
		}else{
		  return $string;
		}  
	}

	public static function cortarCadena($string, $width, $addString = ''){
		if (strlen($string) >= $width ){
			$cadena_cortada = str_split($string, $width);
			return $cadena_cortada[0] . $addString;
		}else{
			return $string;
		}
	}
	public static function partirTexto($string, $width,$onlyWidth = false)
	{
		if(strlen($string) > $width){
			
			if(strlen($string) > ($width * 2)){
				$calc_width = strlen($string)/2;
			}else{
				$calc_width = $width;	
			}
			if ($onlyWidth)
				$calc_width = $width;
			
			$parts = preg_split('/([\s\n\r]+)/', $string, null, PREG_SPLIT_DELIM_CAPTURE);
			$parts_count = count($parts);

			$length = 0;
			$last_part = 0;
			for (; $last_part < $parts_count; ++$last_part) {
			    $length += strlen($parts[$last_part]);
			    if ($length > $calc_width) { break; }
			}
			$parte1 = implode(array_slice($parts, 0, $last_part));
			$parte2 = implode(array_slice($parts, $last_part));

			return array($parte1, $parte2);
		}else{
		  return $string;
		}
	}

	public static function urlIdioma($codigo)
	{
		//Tenemos que substitur el segmento 1 por el codigo
		$semento1 = \Request::segment(1);
		$ruta = substr(\Request::path(), 3); //obtenemos al ruta despues del segmento 1
		return $codigo . '/' . $ruta;
	}
	public static function obtenerThumb($ruta, $thumbs= 'thumbs')
	{
		$rutafinal = "";
		$rutaCortada = explode('/', $ruta);
		for($i=0; $i<sizeof($rutaCortada); $i++){
			if($i == (sizeof($rutaCortada))-1 ) {
				$rutafinal .= $thumbs .'/';
				$rutafinal .= $rutaCortada[$i];
			}else{
				$rutafinal .= $rutaCortada[$i] .'/';
			}

				 

		}

		return $rutafinal;
	}

	public static function setVar(&$var)
	{
		if(!isset($var)) $var="default";
		return $var;
	}
}