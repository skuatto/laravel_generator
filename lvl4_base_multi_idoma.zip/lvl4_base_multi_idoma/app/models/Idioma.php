<?php

class Idioma extends Eloquent {

	protected $table = 'idioma';


    //Funciones

    
    public function scopeCodigo($query, $codigo)
    {
    	return $query->where('codigo', '=', $codigo);
    }

    public function scopeLenguaje($query)
    {
    	return $query->where('codigo', '=', Session::get('locale'));
    }
    public function scopeEspanyol($query)
    {
    	return $query->where('codigo','=','es');
    }
    public function scopeId($query, $id)
    {
    	return $query->where('idioma.id', '=', $id);
    }
}
