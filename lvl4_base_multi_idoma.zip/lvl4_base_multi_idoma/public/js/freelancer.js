// jQuery for page scrolling feature - requires jQuery Easing plugin
$(function() {
    $('.page-scroll a').bind('click', function(event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top
        }, 1500, 'easeInOutExpo');
        event.preventDefault();
    });
});

// Floating label headings for the contact form
$(function() {
    $("body").on("input propertychange", ".floating-label-form-group", function(e) {
        $(this).toggleClass("floating-label-form-group-with-value", !! $(e.target).val());
    }).on("focus", ".floating-label-form-group", function() {
        $(this).addClass("floating-label-form-group-with-focus");
    }).on("blur", ".floating-label-form-group", function() {
        $(this).removeClass("floating-label-form-group-with-focus");
    });
});

// Highlight the top nav as scrolling occurs


/*


 $('.color').each(function(i) {
                        var position = $(this).position();
                        console.log(position);
                        console.log('min: ' + position.top + ' / max: ' + parseInt(position.top + $(this).height()));
                        $(this).scrollspy({
                            min: position.top,
                            max: position.top + $(this).height(),
                            onEnter: function(element, position) {
                                if(console) console.log('entering ' +  element.id);
                                $("body").css('background-color', element.id);
                            },
                            onLeave: function(element, position) {
                                if(console) console.log('leaving ' +  element.id);
                                $('body').css('background-color','#eee');
                            }
                        });
                    });*/