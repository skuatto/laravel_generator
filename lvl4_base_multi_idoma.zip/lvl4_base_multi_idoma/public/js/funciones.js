

$mas_info_abierta = false;
$menu_abierto = false;
$espaciado_pie = 50;

function cambiar_imagen(imgID, imgNombre){
	var imgActual;
	imgActual = $(imgID).attr('src');
	$(imgID).hover(function(){
	    $(this).attr('src', imgNombre);
	},function(){
	     $(this).attr('src',imgActual); 
	})
}

function IniciarSpy(){
	$('.scrollspy').each(function(i) {
		    var position = $(this).position();
		    var id_seccion = $(this).attr('id');
		    //console.log( position.top + $(this).height());

		     $(this).scrollspy({
		        min: position.top,
		        max: (position.top + $(this).height()),

		        onEnter: function(element, position) {
		           // console.log('entering ' +  element.id + ' s: ' + position.top + $(element).height());
		            switch(id_seccion){
		                case "qui_som" :    $(".menu>li:nth-child(1)").addClass('activo');
		                                    break;
		                case "que_fem" :    $(".menu>li:nth-child(2)").addClass('activo');
		                                    break;
		            }
		            
		        },
		        onLeave: function(element, position) {
		           
		           switch(id_seccion){
		                case "qui_som" :    $(".menu>li:nth-child(1)").removeClass('activo');
		                                    break;
		                case "que_fem" :    $(".menu>li:nth-child(2)").removeClass('activo');
		                                    break;
		            }
		        }

	    	});
	 });
}

function IniciarEsconderContacto(src_image_mas,src_image_menos){
	//Esconder mostar contacto
	 
	$(".mas_info").click(function () {
		var contacto_height = $(".contacto_menu").height();
		var menu_height = $(".menu").height();
		var top_height = 235;
		var posicion_menu = $('#menu_contenedor').position().top + top_height + menu_height + contacto_height;


		$(".contacto_menu").slideToggle();
		if($mas_info_abierta){
			$mas_info_abierta = false;
			$(".mas_info2 img").attr("src", src_image_mas);
		}else{
			// miramos si al desplegar el mas info se pasa del pie, si se pasa subimos el menu
			if( posicion_menu > $('#pie').position().top){
				//$fl_menu.stop().animate({top: $('#menu_contenedor').position().top - 350}, $float_speed, $float_easing);
				$fl_menu.stop().animate({top: $('#pie').position().top - $espaciado_pie - (top_height + menu_height + contacto_height) }, $float_speed, $float_easing);
			}
			$mas_info_abierta = true;
			$(".mas_info2 img").attr("src", src_image_menos);
		}
		
	});

}

function IniciarVentanasModales(){


    //Ventanas modales

   	  var $modal1 = $('.modal_aviso').omniWindow();
	  $('.avis_legal').click(function(e){
	    e.preventDefault();
	    $modal1.trigger('show');
	  });
	$('.close-button').click(function(e){
	  e.preventDefault();
	  $modal1.trigger('hide');
	});		   
	  var $modal2 = $('.modal_politica').omniWindow();
	  $('.politica').click(function(e){
	    e.preventDefault();
	    $modal2.trigger('show');
	  });
	$('.close-button2').click(function(e){
	  e.preventDefault();
	  $modal2.trigger('hide');
	});		   
}

function IniciarDropdown(){
	// Menu despegable
        $('#dropdown-1').on('show', function(event, dropdownData) {
			$('#dropdown-1').mouseleave(function () {
		          $('#dropdown-1').dropdown('hide');
		    });
		});
}

function IniciarMenuflotante(){
// Hacer el menu flotante
 
  	$float_speed=1500; //milliseconds
	$float_easing="easeOutQuint";
	$menu_fade_speed=0; //milliseconds
	$closed_menu_opacity=1;

	//cache vars
	$fl_menu=$("#menu_contenedor");
	$fl_menu_menu=$("#menu_contenedor .menu");
	$fl_menu_label=$("#menu_contenedor .siguenos");
	 

    menuPosition=$('#menu_contenedor').position().top;
    FloatMenu();
	 
	
	 
	$(window).scroll(function () {
	    FloatMenu();
	});
	 	
	
	function FloatMenu(){
	    var scrollAmount=$(document).scrollTop();
	    var newPosition=menuPosition+scrollAmount;
	    var espaciado = $espaciado_pie;
	    if($menu_abierto)
	    	espaciado += $(".menu ul").height();

	    if($mas_info_abierta)
	    	espaciado += $(".contacto_menu").height();

	    if(newPosition < ($('#pie').position().top - $('#pie').height() - espaciado) ){
        	$fl_menu.stop().animate({top: newPosition}, $float_speed, $float_easing);
	    }
	}
}


function IniciarMenuPie(){
    // Menu pie de pagina
      $('.menu_pie > li > a').click(function(){
     	if($(this).parent().has('ul').length){
		    if ($(this).attr('class') != 'abierto'){
		      $('.menu li ul').slideUp();
		      $(this).next().slideToggle();
		      $('.menu li a').removeClass('abierto');
		      $(this).addClass('abierto');
		    }
		}
	  });
}

function IniciarMenuLateral(){
 	// Menu lateral
 	 	

     $menu_abierto = false;
     $mas_info_abierta = false;
     $('.menu > li > a').click(function(){
     	if($(this).parent().has('ul').length){

		    if ($(this).attr('class') != 'abierto'){

		    	var top_height = 235;
      			var contacto_height = $(".contacto_menu").height();
      			var menu_height = $(".menu").height();
      			var submenu_height = $(".menu ul").height();
      			
      			var altura = top_height + menu_height + contacto_height;
  				if($mas_info_abierta)
    				altura += contacto_height;

  				var posicion_menu = $('#menu_contenedor').position().top + altura;	

		      	$('.menu li ul').slideUp();
		      	$(this).next().slideToggle();
		      	$('.menu li a').removeClass('abierto');
		      	$(this).addClass('abierto');
		      	$menu_abierto = true;
		      	
	      	  

		        if( posicion_menu > $('#pie').position().top){
					$fl_menu.stop().animate({top: $('#pie').position().top - (altura - 165) }, $float_speed, $float_easing);
				}
		    }
		}
	  });
}